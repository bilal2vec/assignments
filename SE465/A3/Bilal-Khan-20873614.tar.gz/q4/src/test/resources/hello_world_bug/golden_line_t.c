#property tests: 36. int printf(const char*, ...);
int main (int argc, char *argv[]) {
 printf("world\n");
}