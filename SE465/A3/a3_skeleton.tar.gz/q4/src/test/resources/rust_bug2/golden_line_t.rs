#property tests: 46. #![feature(rustc_attrs)]
#[rustc_variance]
use self::Enum::Variant;