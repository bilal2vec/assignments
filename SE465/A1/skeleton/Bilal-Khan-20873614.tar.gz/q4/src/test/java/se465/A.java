package se465;

class A {
  public void m() {
    System.out.println("a");
  }
}
