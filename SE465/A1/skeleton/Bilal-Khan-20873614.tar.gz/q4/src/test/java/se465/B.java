package se465;

class B extends A {
  public void m() {
    System.out.println("b");
  }
}
