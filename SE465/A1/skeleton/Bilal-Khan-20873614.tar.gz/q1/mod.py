#!/usr/bin/env python3
import sys

x = int(sys.argv[1])
print(x % 2)