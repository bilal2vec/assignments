#!/usr/bin/env perl

$x = $ARGV[0];
$y = $x % 2;

print "$y\n";
