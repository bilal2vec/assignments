public class Mod {
  public static void main(String[] argv) {
    var x = Integer.parseInt(argv[0]);
    System.out.println(x % 2);
  }
}
